package br.edu.fatecpg.vendasOnline.model;

public class ProdutoEletronico extends Produto {
    public ProdutoEletronico(String nome, double preco) {
        super(nome, preco);
    }
}
