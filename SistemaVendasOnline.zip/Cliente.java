package br.edu.fatecpg.vendasOnline.model;

public class Cliente {
    private String nome;

    public Cliente(String nome, boolean b) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public boolean isVip() {
        return false;
    }
}

