package br.edu.fatecpg.vendasOnline.model;

import java.util.ArrayList;

public class CarrinhoDeCompras {
    private ArrayList<Produto> produtos;

    public CarrinhoDeCompras() {
        produtos = new ArrayList<>();
    }

    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
    }

    public double calcularTotal(Cliente cliente, boolean pagamentoPix) {
        double total = 0;
        for (Produto produto : produtos) {
            total += produto.getPreco();
        }
        if (cliente.isVip() || produtos.size() > 10) {
            return total; 
        }
        if (pagamentoPix) {
            total *= 0.9;
        }
        return total;
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }
}

