package br.edu.fatecpg.vendasOnline.model;

public class ClienteVIP extends Cliente {
    public ClienteVIP(String nome) {
        super(nome, true);
    }
}
