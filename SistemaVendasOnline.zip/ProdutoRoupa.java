package br.edu.fatecpg.vendasOnline.model;

public class ProdutoRoupa extends Produto {
    public ProdutoRoupa(String nome, double preco) {
        super(nome, preco);
    }
}
