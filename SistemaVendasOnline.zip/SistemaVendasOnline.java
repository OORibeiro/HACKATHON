package br.edu.fatecpg.vendasOnline.view;
import br.edu.fatecpg.vendasOnline.model.Produto;
import br.edu.fatecpg.vendasOnline.model.Cliente;
import br.edu.fatecpg.vendasOnline.model.CarrinhoDeCompras;
import br.edu.fatecpg.vendasOnline.model.ClienteVIP;
import br.edu.fatecpg.vendasOnline.model.ProdutoEletronico;
import br.edu.fatecpg.vendasOnline.model.ProdutoRoupa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SistemaVendasOnline extends JFrame {
    private CarrinhoDeCompras carrinho;
    private DefaultListModel<Produto> modeloLista;
    private JList<Produto> listaProdutos;
    private JTextArea areaStatus;
    private JButton btnAdicionar;
    private JButton btnFinalizar;

    public SistemaVendasOnline() {
        carrinho = new CarrinhoDeCompras();
        modeloLista = new DefaultListModel<>();
        modeloLista.addElement(new ProdutoEletronico("Smartphone", 1500));
        modeloLista.addElement(new ProdutoRoupa("Camisa", 100));

        listaProdutos = new JList<>(modeloLista);
        areaStatus = new JTextArea(5, 20);
        btnAdicionar = new JButton("Adicionar ao Carrinho");
        btnFinalizar = new JButton("Finalizar Compra");

        btnAdicionar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Produto produtoSelecionado = listaProdutos.getSelectedValue();
                if (produtoSelecionado != null) {
                    carrinho.adicionarProduto(produtoSelecionado);
                    areaStatus.append(produtoSelecionado.getNome() + " adicionado ao carrinho.\n");
                }
            }
        });

        btnFinalizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nomeCliente = JOptionPane.showInputDialog("Nome do Cliente:");
                boolean isVip = JOptionPane.showConfirmDialog(null, "Cliente VIP?", "Status", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
                Cliente cliente = new Cliente(nomeCliente, isVip);
                boolean pagamentoPix = JOptionPane.showConfirmDialog(null, "Pagamento via PIX?", "Pagamento", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;

                
               double total = carrinho.calcularTotal(cliente, pagamentoPix);
                areaStatus.append("Total a pagar: R$ " + total + "\n");
                areaStatus.append("Compra finalizada!\n");
                carrinho = new CarrinhoDeCompras();
            }
        });

        setLayout(new FlowLayout());
        add(new JScrollPane(listaProdutos));
        add(btnAdicionar);
        add(btnFinalizar);
        add(new JScrollPane(areaStatus));

        setTitle("Sistema de Vendas Online");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new SistemaVendasOnline();
    }
}
