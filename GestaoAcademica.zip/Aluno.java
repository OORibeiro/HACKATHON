public class Aluno extends Usuario {
    private Disciplina[] disciplinas;
    private double[] notas;
    private int capacidade;
    private int totalDisciplinas;
 
    public Aluno(String nome, String matricula, int capacidade) {
        super(nome, matricula);
        this.capacidade = capacidade;
        this.disciplinas = new Disciplina[capacidade];
        this.notas = new double[capacidade];
        this.totalDisciplinas = 0;
    }
 
    public void adicionarNota(Disciplina disciplina, double nota) {
        if (totalDisciplinas < capacidade) {
            disciplinas[totalDisciplinas] = disciplina;
            notas[totalDisciplinas] = nota;
            totalDisciplinas++;
        } else {
            System.out.println("Capacidade máxima de disciplinas para o aluno atingida.");
        }
    }
 
    public void gerarHistorico() {
        System.out.println("Histórico Acadêmico de " + nome);
        for (int i = 0; i < totalDisciplinas; i++) {
            System.out.println("Disciplina: " + disciplinas[i].getNome() + " - Nota: " + notas[i]);
        }
    }
}