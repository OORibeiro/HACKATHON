package GestaoAcademica.view;

import GestaoAcademica.model.Aluno;
import GestaoAcademica.model.Disciplina;
import GestaoAcademica.model.Professor;
import GestaoAcademica.model.SistemaAcademico;
import GestaoAcademica.model.Usuario;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class GestaoAcademicaInterface {
    private SistemaAcademico sistema; // Sistema acadêmico
    private JFrame frame;

    public GestaoAcademicaInterface() {
        sistema = new SistemaAcademico(); // Inicializa o sistema acadêmico
        frame = new JFrame("Sistema Acadêmico");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        // Painel principal
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new FlowLayout());

        JButton btnAdicionarAluno = new JButton("Adicionar Aluno");
        JButton btnAdicionarProfessor = new JButton("Adicionar Professor");
        JButton btnAdicionarDisciplina = new JButton("Adicionar Disciplina");
        JButton btnAtribuirNota = new JButton("Atribuir Nota");
        JButton btnGerarHistorico = new JButton("Gerar Histórico");

        panelPrincipal.add(btnAdicionarAluno);
        panelPrincipal.add(btnAdicionarProfessor);
        panelPrincipal.add(btnAdicionarDisciplina);
        panelPrincipal.add(btnAtribuirNota);
        panelPrincipal.add(btnGerarHistorico);

        frame.add(panelPrincipal, BorderLayout.NORTH);

        // Ações dos botões
        btnAdicionarAluno.addActionListener(e -> mostrarFormularioAdicionarAluno());
        btnAdicionarProfessor.addActionListener(e -> mostrarFormularioAdicionarProfessor());
        btnAdicionarDisciplina.addActionListener(e -> mostrarFormularioAdicionarDisciplina());
        btnAtribuirNota.addActionListener(e -> mostrarFormularioAtribuirNota());
        btnGerarHistorico.addActionListener(e -> mostrarFormularioGerarHistorico());

        frame.setVisible(true);
    }

    private void mostrarFormularioAdicionarAluno() {
        JFrame frameAluno = new JFrame("Adicionar Aluno");
        frameAluno.setSize(300, 200);
        frameAluno.setLayout(new GridLayout(4, 2));

        JLabel lblNome = new JLabel("Nome:");
        JTextField txtNome = new JTextField();
        JLabel lblMatricula = new JLabel("Matrícula:");
        JTextField txtMatricula = new JTextField();
        JLabel lblCapacidade = new JLabel("Capacidade:");
        JTextField txtCapacidade = new JTextField();
        JButton btnAdicionar = new JButton("Adicionar");

        frameAluno.add(lblNome);
        frameAluno.add(txtNome);
        frameAluno.add(lblMatricula);
        frameAluno.add(txtMatricula);
        frameAluno.add(lblCapacidade);
        frameAluno.add(txtCapacidade);
        frameAluno.add(btnAdicionar);

        btnAdicionar.addActionListener(e -> {
            String nome = txtNome.getText();
            String matricula = txtMatricula.getText();
            int capacidade = Integer.parseInt(txtCapacidade.getText());
            Aluno aluno = new Aluno(nome, matricula, capacidade);
            sistema.registrarAluno(aluno);
            JOptionPane.showMessageDialog(frameAluno, "Aluno adicionado com sucesso!");
            frameAluno.dispose();
        });

        frameAluno.setVisible(true);
    }

    private void mostrarFormularioAdicionarProfessor() {
        JFrame frameProfessor = new JFrame("Adicionar Professor");
        frameProfessor.setSize(300, 200);
        frameProfessor.setLayout(new GridLayout(3, 2));

        JLabel lblNome = new JLabel("Nome:");
        JTextField txtNome = new JTextField();
        JLabel lblMatricula = new JLabel("Matrícula:");
        JTextField txtMatricula = new JTextField();
        JButton btnAdicionar = new JButton("Adicionar");

        frameProfessor.add(lblNome);
        frameProfessor.add(txtNome);
        frameProfessor.add(lblMatricula);
        frameProfessor.add(txtMatricula);
        frameProfessor.add(btnAdicionar);

        btnAdicionar.addActionListener(e -> {
            String nome = txtNome.getText();
            String matricula = txtMatricula.getText();
            Professor professor = new Professor(nome, matricula);
            sistema.registrarProfessor(professor);
            JOptionPane.showMessageDialog(frameProfessor, "Professor adicionado com sucesso!");
            frameProfessor.dispose();
        });

        frameProfessor.setVisible(true);
    }

    private void mostrarFormularioAdicionarDisciplina() {
        JFrame frameDisciplina = new JFrame("Adicionar Disciplina");
        frameDisciplina.setSize(300, 200);
        frameDisciplina.setLayout(new GridLayout(3, 2));

        JLabel lblNome = new JLabel("Nome:");
        JTextField txtNome = new JTextField();
        JLabel lblCapacidade = new JLabel("Capacidade:");
        JTextField txtCapacidade = new JTextField();
        JButton btnAdicionar = new JButton("Adicionar");

        frameDisciplina.add(lblNome);
        frameDisciplina.add(txtNome);
        frameDisciplina.add(lblCapacidade);
        frameDisciplina.add(txtCapacidade);
        frameDisciplina.add(btnAdicionar);

        btnAdicionar.addActionListener(e -> {
            String nome = txtNome.getText();
            int capacidade = Integer.parseInt(txtCapacidade.getText());
            Disciplina disciplina = new Disciplina(nome, capacidade);
            sistema.adicionarDisciplina(disciplina);
            JOptionPane.showMessageDialog(frameDisciplina, "Disciplina adicionada com sucesso!");
            frameDisciplina.dispose();
        });

        frameDisciplina.setVisible(true);
    }

    private void mostrarFormularioAtribuirNota() {
        JFrame frameNota = new JFrame("Atribuir Nota");
        frameNota.setSize(300, 200);
        frameNota.setLayout(new GridLayout(4, 2));

        JLabel lblNomeAluno = new JLabel("Nome do Aluno:");
        JTextField txtNomeAluno = new JTextField();
        JLabel lblNomeDisciplina = new JLabel("Nome da Disciplina:");
        JTextField txtNomeDisciplina = new JTextField();
        JLabel lblNota = new JLabel("Nota:");
        JTextField txtNota = new JTextField();
        JButton btnAtribuir = new JButton("Atribuir");

        frameNota.add(lblNomeAluno);
        frameNota.add(txtNomeAluno);
        frameNota.add(lblNomeDisciplina);
        frameNota.add(txtNomeDisciplina);
        frameNota.add(lblNota);
        frameNota.add(txtNota);
        frameNota.add(btnAtribuir);

        btnAtribuir.addActionListener(e -> {
            String nomeAluno = txtNomeAluno.getText();
            String nomeDisciplina = txtNomeDisciplina.getText();
            double nota = Double.parseDouble(txtNota.getText());

            Aluno aluno = buscarAluno(nomeAluno);
            Disciplina disciplina = buscarDisciplina(nomeDisciplina);

            if (aluno != null && disciplina != null) {
                Professor professor = new Professor("Professor Exemplo", "P001"); // Substituir com o professor real
                professor.atribuirNota(disciplina, aluno, nota);
                JOptionPane.showMessageDialog(frameNota, "Nota atribuída com sucesso!");
                frameNota.dispose();
            } else {
                JOptionPane.showMessageDialog(frameNota, "Aluno ou disciplina não encontrados.");
            }
        });

        frameNota.setVisible(true);
    }

    private Aluno buscarAluno(String nome) {
        for (Aluno aluno : sistema.alunos) {
            if (aluno.getNome().equalsIgnoreCase(nome)) {
                return aluno;
            }
        }
        return null; // Retorna nulo se não encontrar
    }

    private Disciplina buscarDisciplina(String nome) {
        for (Disciplina disciplina : sistema.disciplinas) {
            if (disciplina.getNome().equalsIgnoreCase(nome)) {
                return disciplina;
            }
        }
        return null; // Retorna nulo se não encontrar
    }

    private void mostrarFormularioGerarHistorico() {
        JFrame frameHistorico = new JFrame("Gerar Histórico");
        frameHistorico.setSize(300, 200);
        frameHistorico.setLayout(new GridLayout(2, 2));

        JLabel lblNomeAluno = new JLabel("Nome do Aluno:");
        JTextField txtNomeAluno = new JTextField();
        JButton btnGerar = new JButton("Gerar");

        frameHistorico.add(lblNomeAluno);
        frameHistorico.add(txtNomeAluno);
        frameHistorico.add(btnGerar);

        btnGerar.addActionListener(e -> {
            String nomeAluno = txtNomeAluno.getText();
            Aluno aluno = buscarAluno(nomeAluno);

            if (aluno != null) {
                aluno.gerarHistorico();
            } else {
                JOptionPane.showMessageDialog(frameHistorico, "Aluno não encontrado.");
            }
        });

        frameHistorico.setVisible(true);
    }

    public static void main(String[] args) {
        new GestaoAcademicaInterface(); // Corrigido para chamar a classe certa
    }
}
