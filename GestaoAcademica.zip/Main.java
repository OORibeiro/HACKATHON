public class Main {
    public static void main(String[] args) {
        SistemaAcademico sistema = new SistemaAcademico();
 
        Disciplina matematica = new Disciplina("Matemática", 10);
        Disciplina portugues = new Disciplina("Português", 10);
        sistema.adicionarDisciplina(matematica);
        sistema.adicionarDisciplina(portugues);
 
        Aluno aluno1 = new Aluno("João", "A001", 5);
        Aluno aluno2 = new Aluno("Maria", "A002", 5);
        sistema.registrarAluno(aluno1);
        sistema.registrarAluno(aluno2);

        Professor professor = new Professor("Dr. Silva", "P001");
        sistema.registrarProfessor(professor);
 
        professor.atribuirNota(matematica, aluno1, 8.5);
        professor.atribuirNota(portugues, aluno1, 7.0);
        professor.atribuirNota(matematica, aluno2, 9.0);

        sistema.exibirHistorico(aluno1);
        sistema.exibirHistorico(aluno2);
    }
}