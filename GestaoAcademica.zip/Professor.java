package GestaoAcademica.model;


public class Professor extends Usuario {
 
    public Professor(String nome, String matricula) {
        super(nome, matricula);
    }
 
    public void atribuirNota(Disciplina disciplina, Aluno aluno, double nota) {
        disciplina.adicionarAlunoNota(aluno, nota);
        aluno.adicionarNota(disciplina, nota);
        System.out.println("Nota " + nota + " atribuída para " + aluno.getNome() + " em " + disciplina.getNome());
    }
}