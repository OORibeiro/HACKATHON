package GestaoAcademica.model;

public class Disciplina {
    private String nome;
    private Aluno[] alunos;
    private double[] notas;
    private int capacidade;
    private int totalAlunos; 
 
    public Disciplina(String nome, int capacidade) {
        this.nome = nome;
        this.capacidade = capacidade;
        this.alunos = new Aluno[capacidade];
        this.notas = new double[capacidade];
        this.totalAlunos = 0;
    }
 
    public String getNome() {
        return nome;
    }
 
    public void adicionarAlunoNota(Aluno aluno, double nota) {
        if (totalAlunos < capacidade) {
            alunos[totalAlunos] = aluno;
            notas[totalAlunos] = nota;
            totalAlunos++;
        } else {
            System.out.println("Capacidade máxima da disciplina atingida.");
        }
    }
 
    public Double getNota(Aluno aluno) {
        for (int i = 0; i < totalAlunos; i++) {
            if (alunos[i] == aluno) {
                return notas[i];
            }
        }
        return null;
    }
}