import java.util.ArrayList;
import java.util.List;
 
public class SistemaAcademico {
    private List<Aluno> alunos;
    private List<Professor> professores;
    private List<Disciplina> disciplinas;
 
    public SistemaAcademico() {
        this.alunos = new ArrayList<>();
        this.professores = new ArrayList<>();
        this.disciplinas = new ArrayList<>();
    }
 
    public void registrarAluno(Aluno aluno) {
        alunos.add(aluno);
    }
 
    public void registrarProfessor(Professor professor) {
        professores.add(professor);
    }
 
    public void adicionarDisciplina(Disciplina disciplina) {
        disciplinas.add(disciplina);
    }
 
    public void exibirHistorico(Aluno aluno) {
        aluno.gerarHistorico();
    }
}